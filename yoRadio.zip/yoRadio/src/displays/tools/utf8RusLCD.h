#ifndef utf8RusLCD_h
#define  utf8RusLCD_h


#ifdef POL_LCD

char* DspCore::utf8Rus(const char* str, bool uppercase) {

  int index = 0;
  static char strn[BUFLEN];
  static char newStr[BUFLEN];
  bool E = false;
  strlcpy(strn, str, BUFLEN);
  newStr[0] = '\0';
  bool next = true; //false;

  
  
  while (*str) {
    byte charIndex = 255;
    if ((*str & 0xE0) == 0xC0 || (*str & 0xF0) == 0xE0 || (*str & 0xF8) == 0xF0) {
      // UTF-8 obsługa znaków
      uint16_t code = 0;
      if ((*str & 0xE0) == 0xC0) { // 2 bajty UTF-8
        code = ((*str & 0x1F) << 6) | (*(str + 1) & 0x3F);
        str += 2;
      } else if ((*str & 0xF0) == 0xE0) { // 3 bajty UTF-8
        code = ((*str & 0x0F) << 12) | ((*(str + 1) & 0x3F) << 6) | (*(str + 2) & 0x3F);
        str += 3;
      } else if ((*str & 0xF8) == 0xF0) { // 4 bajty UTF-8
        code = ((*str & 0x07) << 18) | ((*(str + 1) & 0x3F) << 12) | ((*(str + 2) & 0x3F) << 6) | (*(str + 3) & 0x3F);
        str += 4;
      }

      switch (code) {
        case 0x0104: charIndex = 0; break; // Ą
        case 0x0105: charIndex = 0; break; // ą
        case 0x0118: charIndex = 1; break; // Ę
        case 0x0119: charIndex = 1; break; // ę
        case 0x00D3: charIndex = 2; break; // Ó
        case 0x00F3: charIndex = 2; break; // ó
        case 0x0106: charIndex = 3; break; // Ć
        case 0x0107: charIndex = 3; break; // ć
        case 0x0141: charIndex = 4; break; // Ł
        case 0x0142: charIndex = 4; break; // ł
        case 0x0143: charIndex = 5; break; // Ń
        case 0x0144: charIndex = 5; break; // ń
        case 0x015A: charIndex = 6; break; // Ś
        case 0x015B: charIndex = 6; break; // ś
        case 0x017B: charIndex = 7; break; // Ż
        case 0x017C: charIndex = 7; break; // ż
        default: newStr[index++] ='?'; continue; // Zastąp nieznany znak znakiem zapytania
      }

      
    }

  if (charIndex != 255) {
      newStr[index++] = charIndex;
    }
    else {
      newStr[index++] = *str; // Obsługa normalnych znaków ASCII
      str++;
    }
  } //end while
  newStr[index] = 0;
  return newStr;
}


#else  //original RUS code
char* DspCore::utf8Rus(const char* str, bool uppercase) { 
  int index = 0;
  static char strn[BUFLEN];
  static char newStr[BUFLEN];
  bool E = false;
  strlcpy(strn, str, BUFLEN);
  newStr[0] = '\0';
  bool next = false;
  for (char *iter = strn; *iter != '\0'; ++iter)
  {
    if (E) {
      E = false;
      continue;
    }
    byte rus = (byte) * iter;
    if (rus == 208 && (byte) * (iter + 1) == 129) { // ёКостыли
      *iter = (char)209;
      *(iter + 1) = (char)145;
      E = true;
      continue;
    }
    if (rus == 209 && (byte) * (iter + 1) == 145) {
      *iter = (char)209;
      *(iter + 1) = (char)145;
      E = true;
      continue;
    }
    if (next) {
      if (rus >= 128 && rus <= 143) *iter = (char)(rus + 32);
      if (rus >= 176 && rus <= 191) *iter = (char)(rus - 32);
      next = false;
    }
    if (rus == 208) next = true;
    if (rus == 209) {
      *iter = (char)208;
      next = true;
    }
    *iter = toupper(*iter);
  }

  while (strn[index])
  {
    if (strlen(newStr) > BUFLEN - 2) break;
    if (strn[index] >= 0xBF)
    {
      switch (strn[index]) {
        case 0xD0: {
            switch (strn[index + 1])
            {
              case 0x90: strcat(newStr, "A"); break;
              case 0x91: strcat(newStr, "B"); break;
              case 0x92: strcat(newStr, "V"); break;
              case 0x93: strcat(newStr, "G"); break;
              case 0x94: strcat(newStr, "D"); break;
              case 0x95: strcat(newStr, "E"); break;
              case 0x96: strcat(newStr, "ZH"); break;
              case 0x97: strcat(newStr, "Z"); break;
              case 0x98: strcat(newStr, "I"); break;
              case 0x99: strcat(newStr, "Y"); break;
              case 0x9A: strcat(newStr, "K"); break;
              case 0x9B: strcat(newStr, "L"); break;
              case 0x9C: strcat(newStr, "M"); break;
              case 0x9D: strcat(newStr, "N"); break;
              case 0x9E: strcat(newStr, "O"); break;
              case 0x9F: strcat(newStr, "P"); break;
              case 0xA0: strcat(newStr, "R"); break;
              case 0xA1: strcat(newStr, "S"); break;
              case 0xA2: strcat(newStr, "T"); break;
              case 0xA3: strcat(newStr, "U"); break;
              case 0xA4: strcat(newStr, "F"); break;
              case 0xA5: strcat(newStr, "H"); break;
              case 0xA6: strcat(newStr, "TS"); break;
              case 0xA7: strcat(newStr, "CH"); break;
              case 0xA8: strcat(newStr, "SH"); break;
              case 0xA9: strcat(newStr, "SHCH"); break;
              case 0xAA: strcat(newStr, "'"); break;
              case 0xAB: strcat(newStr, "YU"); break;
              case 0xAC: strcat(newStr, "'"); break;
              case 0xAD: strcat(newStr, "E"); break;
              case 0xAE: strcat(newStr, "YU"); break;
              case 0xAF: strcat(newStr, "YA"); break;
            }
            break;
          }
        case 0xD1: {
            if (strn[index + 1] == 0x91) {
              strcat(newStr, "YO"); break;
              break;
            }
            break;
          }
      }
      int sind = index + 2;
      while (strn[sind]) {
        strn[sind - 1] = strn[sind];
        sind++;
      }
      strn[sind - 1] = 0;
    } else {
    	if(strn[index]==7) strn[index]=165;
    	if(strn[index]==9) strn[index]=223;
      char Temp[2] = {(char) strn[index] , 0 } ;
      strcat(newStr, Temp);
    }
    index++;
  }
  return newStr;
}
#endif

#endif
