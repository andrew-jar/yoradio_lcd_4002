#include "../core/options.h"

#if DSP_MODEL==DSP_1602I2C || DSP_MODEL==DSP_1602 || DSP_MODEL==DSP_2004 || DSP_MODEL==DSP_2004I2C

#include "displayLC1602.h"
#include "../core/player.h"
#include "../core/config.h"
#include "../core/network.h"

#ifndef SCREEN_ADDRESS
  #define SCREEN_ADDRESS 0x27 ///< See datasheet for Address or scan it https://create.arduino.cc/projecthub/abdularbi17/how-to-scan-i2c-address-in-arduino-eaadda
#endif

DspCore::DspCore(): DSP_INIT {}

#include "tools/utf8RusLCD.h"



void DspCore::apScreen() {
  clear();
  setCursor(0,0);
  print(utf8Rus(const_lcdApMode, false));
  setCursor(0,1);
  print(WiFi.softAPIP().toString().c_str());
#ifdef LCD_2004
  setCursor(0, 2);
  print(utf8Rus(const_lcdApName, false));
  print(apSsid);
  setCursor(0, 3);
  print(utf8Rus(const_lcdApPass, false));
  print(apPassword);
#endif
}

void DspCore::initDisplay() {
#ifdef LCD_I2C
  init();
  backlight();
#else
  #ifdef LCD_2004
    begin(20, 4);
  #else
    begin(40, 2);
  #endif
#endif
  clearClipping();
  
  plTtemsCount = PLMITEMS;
  plCurrentPos = 1;
  
#ifdef POL_LCD



byte char_a[8] = {
  0b00000,
  0b00000,
  0b01110,
  0b00001,
  0b01111,
  0b10001,
  0b01111,
  0b00010
};//ą

byte char_A[8] = {
  0b01110,
  0b10001,
  0b10001,
  0b11111,
  0b10001,
  0b10001,
  0b10001,
  0b00010
};//Ą

byte char_e[8] = {
  0b00000,
  0b00000,
  0b01110,
  0b10001,
  0b11111,
  0b10000,
  0b01110,
  0b00010
};//ę

byte char_E[8] = {
  0b11111,
  0b10000,
  0b10000,
  0b11110,
  0b10000,
  0b10000,
  0b11111,
  0b00010
};//Ę

byte char_o[8] = {
  0b00010,
  0b00100,
  0b01110,
  0b10001,
  0b10001,
  0b10001,
  0b01110,
  0b00000
};//ó


byte char_O[8] = {
  0b00010,
  0b01110,
  0b10101,
  0b10001,
  0b10001,
  0b10001,
  0b01110,
  0b00000
};//Ó

byte char_c[8] = {
  0b00010,
  0b00100,
  0b01110,
  0b10000,
  0b10000,
  0b10001,
  0b01110,
  0b00000
}; //ć

byte char_C[8] = {
  0b00010,
  0b01110,
  0b10101,
  0b10000,
  0b10000,
  0b10001,
  0b01110,
  0b00000
};//Ć

byte char_l[8] = {
  0b01100,
  0b00100,
  0b00110,
  0b01100,
  0b00100,
  0b00100,
  0b01110,
  0b00000
}; //ł 


byte char_L[8] = {
  0b10000,
  0b10000,
  0b10010,
  0b10100,
  0b11000,
  0b10000,
  0b11111,
  0b00000
};//Ł

byte char_n[8] = {
  0b00010,
  0b00100,
  0b10110,
  0b11001,
  0b10001,
  0b10001,
  0b10001,
  0b00000
}; //ń 

byte char_N[8] = {  
  0b00100,
  0b10101,
  0b11001,
  0b10101,
  0b10011,
  0b10001,
  0b10001,
  0b00000
};//Ń

byte char_s[8] = {
  0b00010,
  0b00100,
  0b01110,
  0b10000,
  0b01110,
  0b00001,
  0b11110,
  0b00000
}; //ś  

byte char_S[8] = {
  0b00010,
  0b01111,
  0b10100,
  0b10000,
  0b01110,
  0b00001,
  0b11110,
  0b00000
};//Ś

byte char_z[8] = {
  0b00100,
  0b00000,
  0b11111,
  0b00010,
  0b00100,
  0b01000,
  0b11111,
  0b00000
}; //ż 


byte char_Z[8] = {
  0b00100,
  0b11111,
  0b00001,
  0b00010,
  0b00100,
  0b01000,
  0b11111,
  0b00000
};//Ż

// Małe litery (maksymalnie 8 znaków)


// Dodajemy je do pamięci LCD
createChar(0, char_a );  // ą
createChar(1, char_e );  // ę
createChar(2, char_o );  // ó
createChar(3, char_c );  // ć
createChar(4, char_l );  // ł
createChar(5, char_n );  // ń
createChar(6, char_s );  // ś
createChar(7, char_z );  // ż

/*
// Duze litery (maksymalnie 8 znaków)
// Dodajemy je do pamięci LCD
createChar(0, char_a );  // ą
createChar(1, char_E );  // ę
createChar(2, char_O );  // ó
createChar(3, char_C );  // ć
createChar(4, char_L );  // ł
createChar(5, char_N );  // ń
createChar(6, char_S );  // ś
createChar(7, char_Z );  // ż
*/

#endif  
  
}

void DspCore::drawLogo(uint16_t top) { }

void DspCore::printPLitem(uint8_t pos, const char* item, ScrollWidget& current){
  if (pos == plCurrentPos) {
    current.setText(item);
  } else {
    setCursor(1, pos);
    char tmp[width()] = {0};
    strlcpy(tmp, utf8Rus(item, true), width());
    print(tmp);
  }
}

void DspCore::drawPlaylist(uint16_t currentItem) {
	clear();
  config.fillPlMenu(currentItem - plCurrentPos, plTtemsCount);
  setCursor(0,1);
  write(byte(126));
}

void DspCore::clearDsp(bool black) {
  clear();
}

void DspCore::fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color){
  if(w<2) return;
  char buf[width()+1] = { 0 };
  snprintf(buf, sizeof(buf), "%*s%s", w-1, "", " ");
  setCursor(x, y);
  print(buf);
  setCursor(x, y);
}

uint16_t DspCore::width(){
#ifdef LCD_2004
  return 20;
#else
  return 40;
#endif
}

uint16_t DspCore::height(){
#ifdef LCD_2004
  return 4;
#else
  return 2;
#endif
}

uint8_t DspCore::_charWidth(unsigned char c){
  return 1;
}

uint16_t DspCore::textWidth(const char *txt){
  uint16_t w = 0, l=strlen(txt);
  for(uint16_t c=0;c<l;c++) w+=_charWidth(txt[c]);
  return w;
}

void DspCore::_getTimeBounds() { }

void DspCore::_clockSeconds(){
  setCursor(_timeleft+_dotsLeft, clockTop);
  print((network.timeinfo.tm_sec % 2 == 0)?":":" ");
}

void DspCore::_clockDate(){ }

void DspCore::_clockTime(){ }

void DspCore::printClock(uint16_t top, uint16_t rightspace, uint16_t timeheight, bool redraw) {
  clockTop = 0;
  _timeleft = width()-5;
  _dotsLeft = 2;
  strftime(_timeBuf, sizeof(_timeBuf), "%H:%M", &network.timeinfo);
  if(strcmp(_oldTimeBuf, _timeBuf)!=0 || redraw){
    setCursor(_timeleft, clockTop);
    print(_timeBuf);
    strlcpy(_oldTimeBuf, _timeBuf, sizeof(_timeBuf));
  }
  _clockSeconds();
}

void DspCore::clearClock() {  }

void DspCore::loop(bool force) { 
//  delay(100);
}

void DspCore::charSize(uint8_t textsize, uint8_t& width, uint16_t& height){
  width = 1;
  height = 1;
}

void DspCore::flip(){ }

void DspCore::invert(){ }

void DspCore::sleep(void) { 
  noDisplay();
#ifdef LCD_I2C
  noBacklight();
#endif
}
void DspCore::wake(void) { 
  display();
#ifdef LCD_I2C
  backlight();
#endif
}

void DspCore::writePixel(int16_t x, int16_t y, uint16_t color) { }

void DspCore::writeFillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color) { }

void DspCore::setClipping(clipArea ca){
  _cliparea = ca;
  _clipping = true;
}

void DspCore::clearClipping(){
  _clipping = false;
  setClipping({0, 0, width(), height()});
}

void DspCore::setNumFont(){ }

#endif
